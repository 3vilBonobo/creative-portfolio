# Floor 03 corridor verification

25 November 2026. Implemented locally, pending owner visual acceptance. No dependencies installed and no Git mutation/deployment.

## Changed by this task

- `src/sections/AboutSection.vue`: shared coordinate scene, responsive art/mask selection and separate projected existing portrait. Large decorative wall 03 removed at owner's request; existing section/eyebrow/navigation numbering retained. Tab semantics and keyboard handlers retained.
- `src/data/about.ts`: owner-requested corrections and shorter description grounded in the updated CV; no contact details or original CV published.
- About rules in `src/style.css`: obsolete accumulated About rules replaced, About-only shared gutter overrides removed. Unrelated CSS edits preserved.
- `public/environments/floor-03-about-corridor/v003/` and `/v004/`: versioned supplied assets/instructions and final owner-provided desktop source with measured geometry/mask and lossless runtime encoding.
- `docs/about-artwork.md`, this report; temporary QA/extracted handoff/evidence under `tmp/about-corridor-v003/`.

Extensive Hero/Experience work was already modified and continued changing during this task. Other floors, navigation components, inter-floor transitions and package configuration were not edited by this task. The owner later supplied an updated CV and requested text correction; `src/data/about.ts` was then updated from that document, without publishing the document or personal contact details.

## Browser checks

The complete application at `http://127.0.0.1:5188/#about` and an isolated harness importing the actual production AboutSection, SiteNavigation, FloorNavigator and global styles were exercised. No raster proof was used as a background. Synthetic copy/resizing/failure/preferences are temporary harness scenarios only.

| CSS viewport | Profile | All three tabs | Horizontal overflow |
| --- | --- | --- | --- |
| 1920×1080 | desktop | PASS | None |
| 1440×900 | desktop | PASS | None |
| 1180×820 | tablet-landscape | PASS | None |
| 820×1180 | tablet | PASS | None |
| 390×844 | mobile | PASS | None |
| 844×390 | tablet-landscape | PASS | None |

- PASS: all three tabs/selected state/visible panels at all six dimensions in the final complete application; raw records `compact-app-metrics.json`. Final normal-size isolated measurements are `compact-normal-metrics.json`, also covering 2560×1440.
- PASS: portrait visually inside the physical frame in all four profiles. Shared scene dimensions/mask registration maintained through profile and scrollbar changes. Final desktop uses the new image and its new aperture, never the old mask. Artist-level subpixel approval remains visual.
- PASS: final exact doubled-font checks for all three tabs at all six sizes. Each About element was set to twice its pre-mutation computed font size (desktop intro 20.16→40.32px; mobile intro 18→36px), so viewport-based clamps could not understate the enlargement. No detected horizontal text clipping or document overflow. Raw records: `compact-exact200-metrics.json`. Earlier root-font-doubling checks also passed. Neither claims native browser zoom or physical-device testing.
- PASS: final eight-extra-paragraph scenario with Approach at all six sizes. Section heights grew to approximately 1,560–2,750px while scene proportions remained constant. The corridor is not tiled or vertically stretched. Raw records: `compact-long-metrics.json`.
- PASS: keyboard ArrowRight→Toolkit; End→Approach; Home→Background; Tab→visible Background panel. Focus and selected state agree and cyan outline is visible. Roles, aria-controls and roving tabindex retained.
- PASS: complete-app Floor 04→03 returned both hash and active floor to About.
- PASS: simulated reduced-motion startup sets no GSAP inline opacity/transforms; reduced-motion CSS forces visible stationary text. About has no animated lights. UNVERIFIED: native OS preference switching and screen-reader operation.
- PASS: deliberately missing background/photo requests leave readable HTML, functioning tabs and no horizontal overflow. Intended scenery/photo is unavailable in that failure scenario.
- PASS: fresh complete-app console sample empty. Earlier HMR tab recorded provider/emitsOptions errors during concurrent unrelated updates; a fresh application tab did not reproduce them. No unrelated fix was attempted.
- Used existing dev-only Scene preview to inspect live/day-clear presentation. About does not reuse incompatible old light passes. Lamp-off testing is inapplicable to baked static-light assets.

The owner supplied a new desktop background, requested wider use of the wall and CV-based corrections, then requested smaller type, a shorter section, lighter backing and removal of the wall number. Final `compact-*` evidence reflects all those changes. Earlier captures are superseded. Tablet/mobile artwork is unchanged. Additional 2560×1440 checks cover the wide-wall composition. Default section height is now about 953px there and 844px at 1920×1080, instead of reserving the entire ~1440/~1080px plate. The full portrait remains visible in all tested normal-size states; the lower scenic foreground is deliberately cropped. Long content still expands naturally.

## Automated verification

- PASS: Node 22.13.1 `npm run build`; existing bundle-size warning remains.
- PASS: Node 22.13.1 `node node_modules/vue-tsc/bin/vue-tsc.js --noEmit`.
- PASS: Node 22.13.1 `npm test`, 22/22 tests.
- PASS: v003 supplied asset sizes/hashes/dimensions and portrait equality; v004 source/lossless runtime pixel equality and manifest hashes.
- Installed npm 12 warns that this Node 22 patch is older than its supported range, but commands complete. No tooling configuration was changed.

## Evidence and limits

Final screenshots are `compact-2560x1440.jpg`, `compact-1920x1080.jpg`, `compact-1440x900.jpg`, `compact-1180x820.jpg`, `compact-820x1180.jpg`, `compact-390x844.jpg` and `compact-844x390.jpg` under `tmp/about-corridor-v003/screenshots/`. These are actual browser renders of production components in the isolated harness, with entrance motion reduced and normal text size. Fixed navigation appears at its viewport position within full-page captures. When a short isolated section is smaller than the viewport, the plain body beneath is not part of About; the full application places its unchanged infrastructure transition there. Older screenshots are retained as intermediate evidence only.

Final owner acceptance is needed for the compact placement, measured frame inset, lower reading-deck blend and supplied narrower compositions. New desktop runtime WebP is lossless and 1,692,864 bytes; it preserves the supplied pixels but is heavier than the v003 desktop candidate. Portrait source is untouched. Native zoom, screen readers and physical devices remain unverified; no formal glyph-level WCAG contrast certification is claimed for textured artwork.
